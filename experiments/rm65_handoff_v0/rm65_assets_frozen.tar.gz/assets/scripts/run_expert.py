#!/usr/bin/env python3
"""Record one official adjust_bottle expert episode without a seed search.

Run through scripts/run_logged.py (and an outer timeout) to retain native-library
stdout/stderr too. A killed run leaves result.json at RUNNING, never PASS.
Only a completed official verdict plus validated recording can return exit 0.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback


PROJECT = Path(__file__).resolve().parents[1]
EXPECTED_COMMIT = "6dde57155eafa3e4ebf6ad1f93a7cf7d5d41a755"


def serializable(value):
    if hasattr(value, "tolist"):
        return value.tolist()
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"Not JSON serializable: {type(value).__name__}")


def write_json(path, data):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(data, indent=2, default=serializable) + "\n")
    temporary.replace(path)


def file_record(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def prepare_config(repo, source, output):
    """Follow collect_data.py's embodiment expansion, with explicit bounded settings."""
    import yaml

    upstream = repo / "env_cfg/task_config/demo_clean.yml"
    args = yaml.safe_load(source.read_text())
    baseline = yaml.safe_load(upstream.read_text())
    intended = dict(baseline)
    intended.update(episode_num=1, collect_data=False, eval_video_log=False,
                    need_plan=True, save_data=False)
    if args != intended:
        raise ValueError("Project clean config differs from audited one-episode overrides")
    if args["embodiment"] != ["aloha-agilex"]:
        raise ValueError("Only the audited aloha-agilex embodiment is supported")
    mapping_path = repo / "env_cfg/task_config/_embodiment_config.yml"
    mapping = yaml.safe_load(mapping_path.read_text())
    robot_path = (repo / mapping["aloha-agilex"]["file_path"]).resolve()
    robot_config_path = robot_path / "config.yml"
    robot_config = yaml.safe_load(robot_config_path.read_text())
    args.update(
        task_name="adjust_bottle", task_config=source.stem,
        left_robot_file=str(robot_path), right_robot_file=str(robot_path),
        dual_arm_embodied=True, embodiment_name="aloha-agilex",
        left_embodiment_config=robot_config, right_embodiment_config=robot_config,
        save_path=str(output / "official_data"),
    )
    shutil.copy2(upstream, output / "upstream_demo_clean.yml")
    shutil.copy2(source, output / "project_clean.yml")
    shutil.copy2(robot_config_path, output / "embodiment_config.yml")
    write_json(output / "resolved_config.json", args)
    write_json(output / "config_sources.json", {
        "upstream": file_record(upstream), "project": file_record(source),
        "embodiment_mapping": file_record(mapping_path),
        "embodiment_config": file_record(robot_config_path),
        "overrides": {key: args[key] for key in
                      ("episode_num", "collect_data", "eval_video_log", "need_plan", "save_data")},
    })
    return args


def preflight_plan(task, output):
    """One +10 mm world-z plan, with no trajectory execution or expert call."""
    import imageio.v2 as imageio
    import numpy as np

    obs = task.get_obs()
    for name, data in obs["observation"].items():
        if "rgb" in data:
            imageio.imwrite(output / f"preflight_{name}.png", data["rgb"])
    before_qpos = np.asarray(task.robot.left_entity.get_qpos()).copy()
    before_pose = np.asarray(task.get_arm_pose("left"), dtype=float)
    target = before_pose.copy()
    target[2] += 0.01
    # The official adapter converts its gripper pose to the planner end link.
    # Calling this method plans only; no move()/take_dense_action() is invoked.
    plan = task.robot.left_plan_path(target.tolist())
    after_qpos = np.asarray(task.robot.left_entity.get_qpos()).copy()
    record = {
        "arm": "left", "delta_world_m": [0, 0, 0.01],
        "start_actual_ee_pose": before_pose, "target_ee_pose": target,
        "post_plan_actual_ee_pose": task.get_arm_pose("left"),
        "planner_status": plan.get("status"),
        "ik_status": "NOT_SEPARATELY_EXPOSED_BY_OFFICIAL_ADAPTER",
        "ik_note": "cuRobo plan_single includes IK; only its aggregate Success/Fail is exposed",
        "trajectory_executed": False,
        "qpos_unchanged_during_planning": bool(np.array_equal(before_qpos, after_qpos)),
        "checks": {
            "collision_scope": "Official cuRobo robot configuration and built-in static table world",
            "self_collision": "As configured in the unchanged official cuRobo robot YAML",
            "task_objects_collision": "NOT_CHECKED_BY_THIS_WORLD",
            "other_arm_collision": "NOT_CLAIMED",
            "all_scene_collision": "NOT_CLAIMED",
        },
    }
    finite = legal = shape_ok = False
    if plan.get("status") == "Success":
        position = np.asarray(plan["position"])
        velocity = np.asarray(plan["velocity"])
        bounds = task._arm_joint_bounds(task.robot.left_arm_joints)
        finite = bool(np.isfinite(position).all() and np.isfinite(velocity).all())
        shape_ok = bool(position.ndim == 2 and position.shape[0] > 0
                        and position.shape[1] == len(bounds) and velocity.shape == position.shape)
        excess = float(task._joint_path_excess([plan], bounds)) if shape_ok and finite else None
        legal = bool(excess is not None and excess <= 0)
        record.update(trajectory_shape=list(position.shape), trajectory_finite=finite,
                      trajectory_shape_valid=shape_ok, planned_joints_legal=legal,
                      planned_joint_limit_excess_rad=excess, joint_bounds_rad=bounds)
        np.savez_compressed(output / "preflight_plan.npz", position=position, velocity=velocity)
    accepted = bool(plan.get("status") == "Success" and finite and legal and shape_ok
                    and record["qpos_unchanged_during_planning"])
    write_json(output / "preflight_plan.json", record)
    return {"preflight_acceptance": accepted, "planning_preflight": record}


class LiveRecorder:
    """Observe _update_render during the same play_once call, never replay it."""

    def __init__(self, task, output):
        import imageio.v2 as imageio
        import imageio_ffmpeg

        self.task = task
        self.output = output
        self.imageio = imageio
        self.ffmpeg = imageio_ffmpeg
        self.original_update = task._update_render
        self.original_update_name = f"{type(task).__module__}.{type(task).__name__}._update_render"
        self.enabled = False
        self.busy = False
        self.update_calls = 0
        self.frames = 0
        self.writer = None
        self.log = (output / "observations.jsonl").open("x", buffering=1)
        self.video_path = output / "expert_head.mp4"
        self.first_state = None
        self.last_state = None
        self.camera_names = None
        self.dt = float(task.scene.get_timestep())
        # Upstream take_dense_action calls _update_render at save_freq intervals.
        # Captures at segment boundaries can add frames, so this is explicitly
        # a sampled visualization and is not a timing-accurate simulation clock.
        self.video_fps = 1.0 / (self.dt * task.save_freq)
        task._update_render = self.update_render

    def update_render(self):
        self.original_update()
        if self.enabled and not self.busy:
            self.update_calls += 1
            self.capture("during_play_once")

    def capture(self, phase, save_pngs=False):
        import numpy as np

        self.busy = True
        try:
            obs = self.task.get_obs()
        finally:
            self.busy = False
        camera_data = obs["observation"]
        names = [name for name, data in camera_data.items() if "rgb" in data]
        required = {"head_camera", "left_camera", "right_camera"}
        if not required.issubset(names):
            raise ValueError(f"Missing RGB cameras: expected {required}, got {names}")
        self.camera_names = names
        images = {}
        for name in names:
            rgb = np.asarray(camera_data[name]["rgb"])
            if rgb.dtype != np.uint8 or rgb.ndim != 3 or rgb.shape[2] != 3:
                raise ValueError(f"Unexpected RGB format for {name}: {rgb.shape} {rgb.dtype}")
            images[name] = rgb
        head = np.ascontiguousarray(images["head_camera"])
        if self.writer is None:
            self.writer = self.ffmpeg.write_frames(
                str(self.video_path), (head.shape[1], head.shape[0]), fps=self.video_fps,
                codec="libx264", pix_fmt_in="rgb24", pix_fmt_out="yuv420p",
                quality=7, macro_block_size=1, ffmpeg_log_level="warning",
            )
            self.writer.send(None)
        self.writer.send(head)
        state = {"endpose": obs["endpose"], "joint_action": obs["joint_action"]}
        if self.first_state is None:
            self.first_state = state
        self.last_state = state
        self.log.write(json.dumps({
            "frame_index": self.frames, "phase": phase,
            "official_render_update_index": self.update_calls,
            "wall_time_unix": time.time(), "scene_instance": id(self.task.scene),
            "sim_step": None, "sim_step_note": "Not instrumented; render calls are not sim steps",
            "state": state,
            "rgb": {name: {"shape": list(rgb.shape), "dtype": str(rgb.dtype),
                           "min": int(rgb.min()), "max": int(rgb.max()),
                           "std": float(rgb.std()),
                           "sha256": hashlib.sha256(rgb.tobytes()).hexdigest()}
                    for name, rgb in images.items()},
        }, default=serializable) + "\n")
        if save_pngs:
            for name, rgb in images.items():
                self.imageio.imwrite(self.output / f"{phase}_{name}.png", rgb)
        self.frames += 1

    def close(self):
        self.enabled = False
        self.task._update_render = self.original_update
        try:
            if self.writer is not None:
                self.writer.close()
        finally:
            self.log.flush()
            os.fsync(self.log.fileno())
            self.log.close()

    def validate_video(self):
        if self.frames < 2 or self.update_calls < 1:
            raise RuntimeError("No in-execution video frames were recorded")
        decoder = self.ffmpeg.read_frames(str(self.video_path), pix_fmt="rgb24")
        try:
            metadata = next(decoder)
            decoded_frames = sum(1 for _ in decoder)
        finally:
            decoder.close()
        if decoded_frames != self.frames:
            raise RuntimeError(f"Video incomplete: {decoded_frames} decoded / {self.frames} captured")
        return {"file": str(self.video_path), "decoded_frames": decoded_frames,
                "metadata": metadata, "nominal_fps": self.video_fps,
                "timing_note": "Sampled at official render updates, not a real-time recording"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=PROJECT / "vendor/RoboTwin")
    parser.add_argument("--config", type=Path, default=PROJECT / "configs/astra_clean.yml")
    parser.add_argument("--output", type=Path, required=True, help="Must be a new directory")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--preflight-only", action="store_true",
                        help="Gate A only: initialize and plan +10 mm z; do not execute the plan")
    cli = parser.parse_args()
    repo, config, output = cli.repo.resolve(), cli.config.resolve(), cli.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    result = {"status": "RUNNING", "gate": "A" if cli.preflight_only else "B", "task": "adjust_bottle",
              "seed": cli.seed, "episodes_attempted": 0,
              "mode": "planning_preflight" if cli.preflight_only else "expert_episode",
              "expert_type": None if cli.preflight_only else "official play_once, live execution, no replay",
              "argv": sys.argv, "python": sys.executable, "start_wall_time_unix": time.time()}
    write_json(output / "result.json", result)
    task = recorder = None
    completed = False
    try:
        commit = subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip()
        result["robotwin_commit"] = commit
        if commit != EXPECTED_COMMIT:
            raise RuntimeError(f"Unaudited RoboTwin commit: {commit}")
        tracked_diff = subprocess.check_output(
            ["git", "-C", str(repo), "diff", "HEAD", "--"], text=True)
        (output / "upstream_tracked.diff").write_text(tracked_diff)
        if tracked_diff:
            raise RuntimeError("Tracked official code differs from pinned commit")
        args = prepare_config(repo, config, output)
        os.chdir(repo)  # Official asset/config paths are relative to the checkout.
        sys.path.insert(0, str(repo))
        import torch.multiprocessing as mp
        mp.set_start_method("spawn", force=True)  # Same initialization as collect_data.py.
        task = importlib.import_module("envs.adjust_bottle").adjust_bottle()
        from robotwin_runtime import configure_rendering
        result["compatibility_adjustments"] = configure_rendering(task)
        result["episodes_attempted"] = 0 if cli.preflight_only else 1
        result["phase"] = "setup_demo"
        write_json(output / "result.json", result)
        task.setup_demo(now_ep_num=0, seed=cli.seed, **args)
        if cli.preflight_only:
            result["phase"] = "planning_preflight"
            write_json(output / "result.json", result)
            result.update(preflight_plan(task, output))
        else:
            recorder = LiveRecorder(task, output)
            recorder.capture("initial", save_pngs=True)
            result["phase"] = "play_once"
            write_json(output / "result.json", result)
            recorder.enabled = True
            result["official_episode_info"] = task.play_once()
            recorder.enabled = False
            recorder.capture("final", save_pngs=True)
            result["plan_success"] = bool(task.plan_success)
            result["official_check_success"] = bool(task.check_success())
            joints_ok, excess = task.planned_joints_legal()
            result["planned_joints_legal"] = bool(joints_ok)
            result["planned_joint_limit_excess_rad"] = float(excess)
            result["official_acceptance"] = bool(task.plan_success and result["official_check_success"] and joints_ok)
            result["initial_state"] = recorder.first_state
            result["final_state"] = recorder.last_state
            # Store exactly the planner output from this episode for reproducibility.
            task.save_traj_data(0)
        completed = True
    except BaseException as error:
        result["error"] = {"type": type(error).__name__, "message": str(error),
                           "traceback": traceback.format_exc()}
        traceback.print_exc()
    finally:
        if recorder is not None:
            try:
                recorder.close()
                result["video"] = recorder.validate_video()
                result["frames_recorded"] = recorder.frames
                result["camera_names"] = recorder.camera_names
                result["instrumentation"] = {
                    "method": "instance _update_render wrapper; get_obs recursion guarded",
                    "applied_after_setup_demo": True,
                    "in_execution_render_updates": recorder.update_calls,
                }
                result["recording_complete"] = completed
            except BaseException:
                result["recording_error"] = traceback.format_exc()
                traceback.print_exc()
        if task is not None:
            try:
                task.close_env()
            except BaseException:
                result["cleanup_error"] = traceback.format_exc()
                traceback.print_exc()
        accepted = (result.get("preflight_acceptance", False) if cli.preflight_only
                    else result.get("official_acceptance", False) and result.get("recording_complete", False))
        passed = completed and accepted and not result.get("cleanup_error")
        result.update(status="PASS" if passed else "FAIL", phase="finished",
                      end_wall_time_unix=time.time())
        write_json(output / "result.json", result)
        print(json.dumps(result, indent=2, default=serializable), flush=True)
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
