"""Target-device scene: official RM65 + provisional CTAG2F90-D, no RoboTwin robot wrapper."""
import json,math,time,threading,xml.etree.ElementTree as ET
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
from bridge_diagnostics import SceneDiagnostics,enable_stack_dump
from run_expert import write_json

ROOT=Path(__file__).resolve().parents[1]
CONFIG=ROOT/'configs/rm65_ctag_reference'

def camera_pose(position,target):
    import sapien
    p=np.asarray(position,float);f=np.asarray(target,float)-p;f/=np.linalg.norm(f)
    l=np.cross([0,0,1],f)
    if np.linalg.norm(l)<1e-6:l=np.cross([0,1,0],f)
    l/=np.linalg.norm(l);u=np.cross(f,l)
    return sapien.Pose(p,np.roll(Rotation.from_matrix(np.column_stack([f,l,u])).as_quat(),1))

class RM65Scene:
    def __init__(self,output,settle=True,diagnostic_initial=None,without_object=False,solver_velocity_iterations=None):
        import sapien,trimesh
        self.output=Path(output);self.output.mkdir(parents=True,exist_ok=False)
        self.cfg=json.loads((CONFIG/'assembly.json').read_text());self.step=0;self.counter=0;self.step_hook=None
        if solver_velocity_iterations is not None:self.cfg['control']['solver_velocity_iterations']=int(solver_velocity_iterations)
        self.stopped=threading.Event();self.shutdown=threading.Event();self.latest=None
        self.diag=SceneDiagnostics(self.output);self.stack=enable_stack_dump(self.output)
        self.events=(self.output/'events.jsonl').open('x',buffering=1)
        self.private=(self.output/'private_object.jsonl').open('x',buffering=1)
        self.phase('SCENE_INIT')
        self.engine=sapien.Engine();self.renderer=sapien.SapienRenderer();self.engine.set_renderer(self.renderer)
        sapien.render.set_camera_shader_dir('default')
        self.scene=self.engine.create_scene();self.scene.set_timestep(self.cfg['scene']['dt'])
        self.scene.set_ambient_light([.3,.3,.3]);self.scene.add_directional_light([.2,.2,-1],[.8,.8,.8],shadow=True)
        self.material=self.scene.create_physical_material(.5,.5,0.)
        c=self.cfg['scene'];b=self.scene.create_actor_builder()
        b.add_box_collision(half_size=c['table_half_size'],material=self.material)
        b.add_box_visual(half_size=c['table_half_size'],material=[.55,.6,.64])
        self.table=b.build_static(name='table');self.table.set_pose(sapien.Pose(c['table_center']))
        b=self.scene.create_actor_builder();b.add_box_collision(half_size=[.06,.06,.015],material=self.material)
        b.add_box_visual(half_size=[.06,.06,.015],material=[.15,.15,.15])
        self.stand=b.build_static(name='mounting_stand');self.stand.set_pose(sapien.Pose([0,0,.015]))
        b=self.scene.create_actor_builder();b.add_box_collision(half_size=[c['cube_size_m']/2]*3,material=self.material)
        b.add_box_visual(half_size=[c['cube_size_m']/2]*3,material=[.8,.03,.02]);self.cube=b.build(name='target_cube')
        body=self.cube.find_component_by_type(sapien.physx.PhysxRigidDynamicComponent);body.mass=c['cube_mass_kg']
        self.cube_body=body
        self.cube.set_pose(sapien.Pose(c['cube_initial_xyz']))
        if diagnostic_initial is not None and 'object_pose' in diagnostic_initial:
            pose=diagnostic_initial['object_pose'];self.cube.set_pose(sapien.Pose(pose[:3],pose[3:]))
        if without_object:self.scene.remove_actor(self.cube)
        b=self.scene.create_actor_builder();b.add_box_visual(half_size=[c['place_zone_radius_m']]*2+[.0005],material=[.05,.65,.12])
        self.zone=b.build_static(name='placement_marker');self.zone.set_pose(sapien.Pose([*c['place_zone_xy'],.0006]))
        loader=self.scene.create_urdf_loader();loader.fix_root_link=True
        loader.set_material(.5,.5,0.)
        self.robot=loader.load(str(CONFIG/'assembly.urdf'),str(CONFIG/'assembly.srdf'))
        if self.robot is None:raise RuntimeError('URDF_LOAD_FAILED')
        if 'solver_velocity_iterations' in self.cfg['control']:
            self.robot.set_solver_velocity_iterations(self.cfg['control']['solver_velocity_iterations'])
        self.robot.set_root_pose(sapien.Pose(self.cfg['temporary_assembly']['base_world_xyz_m']))
        self.joints=self.robot.get_active_joints();self.names=[j.name for j in self.joints]
        self.links={x.name:x for x in self.robot.get_links()};self.arm_indices=[self.names.index(f'joint{i}') for i in range(1,7)]
        self.master=self.names.index(self.cfg['gripper_master']);self.tree=ET.parse(CONFIG/'assembly.urdf').getroot()
        self.mimics={j.get('name'):(j.find('mimic').get('joint'),float(j.find('mimic').get('multiplier')),float(j.find('mimic').get('offset','0')))
                     for j in self.tree.findall('joint') if j.find('mimic') is not None}
        self.ignore={frozenset([x.get('link1'),x.get('link2')]) for x in ET.parse(CONFIG/'assembly.srdf').getroot().findall('disable_collisions')}
        q=np.zeros(len(self.names));q[self.arm_indices]=self.cfg['control']['initial_arm_q']
        if diagnostic_initial is not None:
            if diagnostic_initial['joint_names']!=self.names:raise ValueError('DIAGNOSTIC_JOINT_ORDER_MISMATCH')
            q=np.asarray(diagnostic_initial['qpos'],float)
        self.robot.set_qpos(q)
        self.arm_target=q[self.arm_indices].copy();self.grip_target=0.
        for i,j in enumerate(self.joints):
            limit=self.tree.find(f"joint[@name='{j.name}']/limit")
            if i in self.arm_indices:j.set_drive_property(self.cfg['control']['arm_stiffness'],self.cfg['control']['arm_damping'],force_limit=float(limit.get('effort')))
            elif i==self.master:j.set_drive_property(self.cfg['control']['gripper_stiffness'],self.cfg['control']['gripper_damping'],force_limit=float(limit.get('effort')))
            else:j.set_drive_property(0.,.1,force_limit=float(limit.get('effort')))
            j.set_drive_target(float(q[i]))
        if diagnostic_initial is not None:
            self.arm_target=np.asarray(diagnostic_initial['arm_target'],float)
            for i,v in zip(self.arm_indices,self.arm_target):self.joints[i].set_drive_target(float(v))
            # Open fingers had a zero drive target at the recorded pre-closure state.
            self.joints[self.master].set_drive_target(0.)
            write_json(self.output/'diagnostic_initial.json',diagnostic_initial)
        self.pad_vertices={}
        for side in ['Left','Right']:
            n=f'ctag_{side}_Support_Link';m=trimesh.load(ROOT/f'vendor/target_models_20260921/crt_ctag2f90d_gripper_visualization/meshes/{side}_Support_Link.STL')
            v=m.vertices[m.vertices[:,1]>.04]
            # Actual inner pad face is the minimum local x face in both symmetric meshes.
            v=v[v[:,0]<v[:,0].min()+.001]
            self.pad_vertices[n]=v
        cam=self.cfg['camera'];self.cameras={}
        a=self.cfg['temporary_assembly']
        for name in ['fixed','wrist','assembly']:
            self.cameras[name]=self.scene.add_camera(name,cam['width'],cam['height'],math.radians(cam['fovy_degrees']),.01,5)
        self.cameras['fixed'].set_pose(camera_pose(a['fixed_camera_xyz_m'],a['fixed_camera_look_at_m']))
        self.cameras['assembly'].set_pose(camera_pose([1.,-.9,.8],[.2,0,.35]))
        self.wrist_relative=camera_pose(a['wrist_camera_xyz_m'],a['wrist_camera_look_at_parent_m'])
        self.motion=None;self.action_count=0;self.initial_object=None;self.max_lift=0.
        self.video_writer=None;self.video_index=None
        write_json(self.output/'assembly_config.json',self.cfg)
        self.phase('INITIAL_STATE')
        if settle:self.tick(100)
        self.initial_object=self.object_pose();write_json(self.output/'initial_object_private.json',self.initial_object)
        write_json(self.output/'loaded_model.json',{'joint_names':self.names,'links':list(self.links),'state':self.state(),
                   'source_manifest':str(ROOT/'vendor/target_models_20260921/manifest.json')})

    def phase(self,name,**kw):self.diag.phase(name,self.step,**kw)
    def log(self,event,data):self.events.write(json.dumps({'event':event,'step':self.step,'monotonic':time.monotonic(),'data':data})+'\n')
    def object_pose(self):
        p=self.cube.get_pose();return [*map(float,p.p),*map(float,p.q)]
    def pads(self):
        points=[]
        for n,v in self.pad_vertices.items():
            t=self.links[n].get_pose().to_transformation_matrix();points.append((v@t[:3,:3].T+t[:3,3]).mean(0))
        return np.asarray(points)
    def state(self):
        p=self.links['Link6'].get_pose();q=self.robot.get_qpos();pads=self.pads()
        return {'sim_step':self.step,'stopped':self.stopped.is_set(),'joint_names':self.names,
                'qpos':q.tolist(),'flange_pose_world':[*map(float,p.p),*map(float,p.q)],
                'actual_pad_centers_world':pads.tolist(),'actual_grasp_center_world':pads.mean(0).tolist(),
                'actual_pad_gap_m':float(np.linalg.norm(pads[0]-pads[1])),'gripper_master_rad':float(q[self.master])}
    def hold(self):
        q=self.robot.get_qpos()
        for i in self.arm_indices:self.joints[i].set_drive_target(float(q[i]));self.joints[i].set_drive_velocity_target(0.)
        self.arm_target=q[self.arm_indices].copy();self.joints[self.master].set_drive_target(float(q[self.master]))
    def monitor(self):
        q=self.robot.get_qpos();lim=self.robot.get_qlimits();tol=self.cfg['control']['joint_limit_tolerance_rad']
        if not np.isfinite(q).all() or np.any(q<lim[:,0]-tol) or np.any(q>lim[:,1]+tol):raise RuntimeError('ACTUAL_JOINT_LIMIT')
        if np.max(np.abs(q[self.arm_indices]-self.arm_target))>self.cfg['control']['max_tracking_error_rad']:raise RuntimeError('TRACKING_ERROR')
        for contact in self.scene.get_contacts():
            names=[x.entity.name for x in contact.bodies];penetration=min([p.separation for p in contact.points],default=0.)
            if penetration>=-.002:continue
            pair=frozenset(names);rs=[n for n in names if n in self.links]
            if len(rs)==2 and pair not in self.ignore:raise RuntimeError('SELF_COLLISION '+str(names))
            if len(rs)==1:
                other=next(n for n in names if n not in self.links)
                allowed=(other in ['table','mounting_stand'] and rs[0]=='base_link') or (other=='target_cube' and rs[0] in self.pad_vertices)
                if other=='target_cube' and rs[0] in self.pad_vertices:raise RuntimeError('PAD_CONTACT_PENETRATION '+str(names))
                if other in ['table','mounting_stand','target_cube'] and not allowed:raise RuntimeError('SCENE_COLLISION '+str(names))
    def tick(self,n):
        started=time.monotonic()
        for _ in range(n):
            if self.stopped.is_set():raise RuntimeError('STOPPED')
            if time.monotonic()-started>self.cfg['control']['physics_timeout_s']:raise TimeoutError('EXECUTION_TIMEOUT')
            self.robot.set_qf(self.robot.compute_passive_force(gravity=True,coriolis_and_centrifugal=True))
            if self.step_hook:self.step_hook('before_step')
            self.scene.step();self.step+=1
            if self.step_hook:self.step_hook('after_step')
            if self.video_writer is not None and self.step%25==0:self.capture_video_frame()
            try:self.monitor()
            except Exception as exc:
                write_json(self.output/'safety_abort.json',{'error':str(exc),'state':self.state(),
                  'contacts':[{'names':[b.entity.name for b in c.bodies],
                    'separations':[float(p.separation) for p in c.points]} for c in self.scene.get_contacts()]})
                self.stopped.set();self.hold();raise
            pose=self.object_pose()
            if self.initial_object is not None:self.max_lift=max(self.max_lift,pose[2]-self.initial_object[2])
            self.private.write(json.dumps({'step':self.step,'pose':pose,'master':float(self.robot.get_qpos()[self.master])})+'\n')
            if self.step%10==0:self.log('feedback',self.state())
    def observe(self,assembly=False):
        from PIL import Image
        self.phase('OBSERVE_ENTER');self.counter+=1;folder=self.output/f'obs_{self.counter:04d}';folder.mkdir()
        self.cameras['wrist'].set_pose(self.links['ctag_base_link'].get_pose()*self.wrist_relative)
        self.scene.update_render();images={};start=time.monotonic()
        for name in (['assembly','fixed','wrist'] if assembly else ['fixed','wrist']):
            self.phase('CAPTURE_ENTER',camera=name);cam=self.cameras[name];cam.take_picture()
            self.phase('READBACK_ENTER',camera=name);rgba=cam.get_picture('Color')
            path=folder/f'{name}.png';Image.fromarray((np.clip(rgba[:,:,:3],0,1)*255).astype('uint8')).save(path)
            images[name]=str(path);self.phase('CAPTURE_EXIT',camera=name)
        self.latest={'id':f'rm65:{self.counter:04d}','time':time.monotonic(),'consumed':False}
        result={'ok':True,'observation_id':self.latest['id'],'images':images,'state':self.state(),'capture_s':time.monotonic()-start}
        write_json(folder/'observation.json',result);self.log('observation',result);self.phase('OBSERVE_REPLY');return result
    def gripper(self,opening):
        if isinstance(opening,bool) or not np.isfinite(opening) or not 0<=opening<=1:raise ValueError('opening must be 0..1')
        if self.stopped.is_set():raise RuntimeError('STOPPED')
        self.action_count+=1;before=self.state();start=float(self.robot.get_qpos()[self.master]);target=-.91*(1-opening)
        self.phase('GRIPPER_ENTER',target=target)
        master=self.joints[self.master]
        source_limit=float(self.tree.find(f"joint[@name='{master.name}']/limit").get('effort'))
        master.set_drive_property(self.cfg['control']['gripper_stiffness'],self.cfg['control']['gripper_damping'],force_limit=source_limit)
        latched=None;contact_steps=0
        for a in np.linspace(start,target,150):
            if latched is None:master.set_drive_target(float(a))
            self.tick(1)
            if target<start and latched is None:
                contact_steps=contact_steps+1 if self.bilateral_pad_contact() else 0
                if contact_steps>=2:latched=self.latch_grasp_contact()
        for _ in range(200):
            self.tick(1)
            if target<start and latched is None:
                contact_steps=contact_steps+1 if self.bilateral_pad_contact() else 0
                if contact_steps>=2:latched=self.latch_grasp_contact()
        result={'ok':True,'before':before,'requested_target_rad':target,
                'target_rad':float(master.get_drive_target()[0]),'contact_latch':latched,'after':self.state()};self.log('gripper',result)
        self.phase('GRIPPER_EXIT');return result
    def bilateral_pad_contact(self):
        touching=set()
        for c in self.scene.get_contacts():
            names=[b.entity.name for b in c.bodies]
            if 'target_cube' not in names:continue
            for n in names:
                if n in self.pad_vertices and any(p.separation<=.0002 and np.linalg.norm(p.impulse)>1e-6 for p in c.points):touching.add(n)
        return touching==set(self.pad_vertices)
    def latch_grasp_contact(self):
        master=self.joints[self.master];actual=float(self.robot.get_qpos()[self.master])
        # Simulation contact hold: 0.1 Nm generalized actuator cap, not a
        # manufacturer's advertised fingertip force interpreted as joint torque.
        # Small finite spring preload, instead of forcing the empty-space target.
        preload=self.cfg['control']['contact_preload_rad'];limit=self.cfg['control']['contact_hold_torque_Nm']
        target=max(-.91,actual-preload)
        master.set_drive_property(self.cfg['control']['gripper_stiffness'],self.cfg['control']['gripper_damping'],force_limit=limit)
        master.set_drive_target(target)
        result={'step':self.step,'actual_rad':actual,'target_rad':target,'force_limit_Nm':limit,'preload_rad':preload}
        self.log('bilateral_contact_latch',result);return result
    def start_video(self):
        import imageio.v2 as imageio
        self.video_writer=imageio.get_writer(str(self.output/'execution.mp4'),fps=1/(25*self.cfg['scene']['dt']),codec='libx264',macro_block_size=1)
        self.video_index=(self.output/'video_frames.jsonl').open('x',buffering=1)
        self.capture_video_frame()
    def capture_video_frame(self):
        self.cameras['wrist'].set_pose(self.links['ctag_base_link'].get_pose()*self.wrist_relative)
        self.scene.update_render();frames=[]
        for name in ['fixed','wrist']:
            self.phase('VIDEO_CAPTURE_ENTER',camera=name);cam=self.cameras[name];cam.take_picture()
            self.phase('VIDEO_READBACK_ENTER',camera=name);rgba=cam.get_picture('Color')
            frames.append((np.clip(rgba[:,:,:3],0,1)*255).astype('uint8'));self.phase('VIDEO_CAPTURE_EXIT',camera=name)
        self.video_writer.append_data(np.concatenate(frames,axis=1))
        self.video_index.write(json.dumps({'sim_step':self.step,'simulation_time_s':self.step*self.cfg['scene']['dt']})+'\n')
    def init_planner(self):
        import yaml
        if self.cfg['control'].get('planner')=='mplib_existing':
            from mplib.sapien_utils import SapienPlanner,SapienPlanningWorld
            from mplib.sapien_utils.conversion import convert_object_name
            self.phase('PLANNER_INIT_ENTER',planner='installed mplib / OMPL / FCL')
            world=SapienPlanningWorld(self.scene,[self.robot])
            self.motion=SapienPlanner(world,'Link6',joint_vel_limits=[1.]*6,joint_acc_limits=[1.]*6)
            for a,b in map(tuple,self.ignore):self.motion.acm.set_entry(a,b,True)
            self.motion.acm.set_entry('base_link',convert_object_name(self.stand),True)
            for link in self.pad_vertices:self.motion.acm.set_entry(link,convert_object_name(self.cube),True)
            self.phase('PLANNER_INIT_EXIT',planner='mplib_existing');return
        from curobo.wrap.reacher.motion_gen import MotionGen,MotionGenConfig
        from curobo.util.logger import setup_logger
        setup_logger(level='error')
        self.phase('PLANNER_INIT_ENTER');self.plan_config=yaml.safe_load((CONFIG/'curobo.yml').read_text())
        if sum(map(len,self.plan_config['robot_cfg']['kinematics']['collision_spheres'].values()))>=1024:
            raise RuntimeError('CUROBO_SPHERE_LIMIT: installed self-collision kernel requires <1024; preserved conservative cover has 1479')
        c=self.cfg['scene'];base=np.asarray(self.cfg['temporary_assembly']['base_world_xyz_m'])
        world={'cuboid':{'table':{'dims':(np.array(c['table_half_size'])*2).tolist(),
            'pose':[*list(np.array(c['table_center'])-base),1,0,0,0]}}}
        mg=MotionGenConfig.load_from_robot_config(self.plan_config,world,interpolation_dt=c['dt'],num_trajopt_seeds=4,num_graph_seeds=4)
        self.motion=MotionGen(mg);self.motion.warmup();self.phase('PLANNER_INIT_EXIT')
    def set_planning_payload(self,carried):
        """GT engineering only: update FCL collision geometry, never PhysX constraints.

        mplib's attach_object operates on its independent PlanningWorld. The
        physical cube remains free, can slip/fall, and is never teleported.
        """
        from mplib.sapien_utils.conversion import convert_object_name
        if self.cfg['control'].get('planner')!='mplib_existing':raise RuntimeError('PAYLOAD_REQUIRES_MPLIB')
        if self.motion is None:self.init_planner()
        self.motion.update_from_simulation();world=self.motion.planning_world;name=convert_object_name(self.cube)
        if carried:
            world.attach_object(name,self.motion.robot.get_name(),self.motion.move_group_link_id,list(self.pad_vertices))
        else:
            world.detach_object(name,False)
            for pad in self.pad_vertices:self.motion.acm.set_entry(pad,name,True)
            self.motion.update_from_simulation()
        self.log('planning_payload',{'carried':carried,'scope':'FCL collision geometry only; no physical constraint or pose write'})
    def move_flange(self,pose):
        pose=np.asarray(pose,float)
        if pose.shape!=(7,) or not np.isfinite(pose).all() or abs(np.linalg.norm(pose[3:])-1)>.001:raise ValueError('INVALID_POSE')
        if self.stopped.is_set():raise RuntimeError('STOPPED')
        if self.motion is None:self.init_planner()
        self.action_count+=1;before=self.state();q=self.robot.get_qpos()
        self.phase('PLAN_ENTER',target_world=pose.tolist());t=time.monotonic()
        if self.cfg['control'].get('planner')=='mplib_existing':
            import mplib
            self.motion.update_from_simulation()
            goal=self.motion._transform_goal_to_wrt_base(mplib.Pose(pose[:3],pose[3:]))
            mask=np.ones(len(q),dtype=bool);mask[self.arm_indices]=False
            ik_status,ik_goal=self.motion.IK(goal,q,mask=mask,return_closest=True)
            self.log('ik',{'status':ik_status,'selection':'closest to actual qpos',
                          'start_qpos':q.tolist(),'goal_qpos':None if ik_goal is None else ik_goal.tolist()})
            r=({'status':ik_status} if ik_status!='Success' else
               self.motion.plan_qpos([ik_goal],q,time_step=self.cfg['scene']['dt'],planning_time=5.,fix_joint_limits=False))
            status=r['status'];success=status=='Success'
            if success:positions=r['position'];velocities=r['velocity']
        else:
            import torch
            from curobo.types.math import Pose
            from curobo.types.robot import JointState
            from curobo.wrap.reacher.motion_gen import MotionGenPlanConfig
            lock={n:float(q[self.names.index(n)]) for n in self.plan_config['robot_cfg']['kinematics']['lock_joints']}
            self.motion.update_locked_joints(lock,self.plan_config)
            target=pose.copy();target[:3]-=self.cfg['temporary_assembly']['base_world_xyz_m']
            start=JointState.from_position(torch.as_tensor(q[self.arm_indices],device='cuda',dtype=torch.float32).reshape(1,-1),joint_names=[f'joint{i}' for i in range(1,7)])
            r=self.motion.plan_single(start,Pose.from_list(target.tolist()),MotionGenPlanConfig(max_attempts=4,timeout=self.cfg['control']['planner_timeout_s']))
            status=str(r.status);success=bool(r.success.item())
            if success:
                trajectory=r.get_interpolated_plan();inds=[trajectory.joint_names.index(f'joint{i}') for i in range(1,7)]
                positions=trajectory.position.cpu().numpy()[:,inds];velocities=trajectory.velocity.cpu().numpy()[:,inds]
        planned=time.monotonic()-t;self.phase('PLAN_EXIT',status=status,success=success,seconds=planned)
        if not success:
            result={'ok':False,'planner_status':status,'before':before,'target_world':pose.tolist()};self.log('plan_failure',result);return result
        if self.stopped.is_set() or planned>self.cfg['control']['planner_timeout_s']:raise RuntimeError('PLANNING_STOP_OR_TIMEOUT')
        limits=self.robot.get_qlimits()[self.arm_indices]
        if not np.isfinite(positions).all() or np.any(positions<limits[:,0]) or np.any(positions>limits[:,1]):raise RuntimeError('PLANNED_JOINT_LIMIT')
        if self.cfg['control'].get('planner')=='mplib_existing':
            for point in positions:
                full=q.copy();full[self.arm_indices]=point
                if self.motion.check_for_self_collision(full) or self.motion.check_for_env_collision(full):raise RuntimeError('INTERPOLATED_PATH_COLLISION')
        np.savez(self.output/f'plan_{self.action_count:03d}.npz',position=positions,velocity=velocities,target=pose)
        self.phase('EXEC_ENTER',trajectory_steps=len(positions));t=time.monotonic()
        for p,v in zip(positions,velocities):
            if time.monotonic()-t>self.cfg['control']['physics_timeout_s']:raise TimeoutError('EXECUTION_TIMEOUT')
            self.arm_target=p.copy()
            for i,qi,vi in zip(self.arm_indices,p,v):self.joints[i].set_drive_target(float(qi));self.joints[i].set_drive_velocity_target(float(vi))
            self.tick(1)
        for i in self.arm_indices:self.joints[i].set_drive_velocity_target(0.)
        self.tick(100);after=self.state();error=float(np.linalg.norm(np.asarray(after['flange_pose_world'][:3])-pose[:3]))
        rotation_error=float((Rotation.from_quat(np.roll(pose[3:],-1)).inv()*Rotation.from_quat(np.roll(after['flange_pose_world'][3:],-1))).magnitude())
        result={'ok':error<.01 and rotation_error<.05,'planner_status':status,'planning_s':planned,
                'trajectory_steps':len(positions),'position_error_m':error,'rotation_error_rad':rotation_error,'before':before,'after':after}
        self.log('move',result);self.phase('EXEC_EXIT',ok=result['ok'])
        if not result['ok']:self.stopped.set();self.hold()
        return result
    def move_tcp(self,pose):
        pose=np.asarray(pose,float);flange=self.links['Link6'].get_pose().to_transformation_matrix()
        local=flange[:3,:3].T@(self.pads().mean(0)-flange[:3,3])
        flange_target=pose.copy();flange_target[:3]-=Rotation.from_quat(np.roll(pose[3:],-1)).as_matrix()@local
        return self.move_flange(flange_target)
    def close(self):
        if self.video_writer is not None:self.video_writer.close();self.video_index.close()
        self.hold();self.phase('CLOSED');self.events.close();self.private.close();self.diag.close()
