"""Scene-thread tracing; health reads only immutable cached Python metadata."""
import faulthandler
import json
import os
import signal
import threading
import time
from functools import wraps


def enable_stack_dump(output):
    stream = (output / "python_stacks.log").open("x", buffering=1)
    faulthandler.enable(file=stream, all_threads=True)
    faulthandler.register(signal.SIGUSR1, file=stream, all_threads=True, chain=False)
    return stream  # Keep the descriptor alive until process exit/explicit cleanup.


class SceneDiagnostics:
    def __init__(self, output):
        self.stream = (output / "phases.jsonl").open("x", buffering=1)
        self.request_id = None
        self.method = None
        self.last_completed = None
        self.snapshot = {}
        self.phase("INITIALIZING", 0)

    def phase(self, name, sim_step, **details):
        record = {"phase": name, "monotonic_time": time.monotonic(),
                  "wall_time_unix": time.time(), "request_id": self.request_id,
                  "method": self.method, "sim_step": sim_step,
                  "thread_id": threading.get_ident(), **details}
        # Atomic reference replacement; health never waits on the scene logger.
        self.snapshot = {**record, "last_completed_request": self.last_completed}
        self.stream.write(json.dumps(record, allow_nan=False) + "\n")
        self.stream.flush()

    def begin(self, request_id, method, sim_step):
        self.request_id, self.method = request_id, method
        self.phase("REQUEST_ENTER", sim_step)

    def complete(self, response, sim_step):
        self.last_completed = {"request_id": self.request_id, "method": self.method,
                               "monotonic_time": time.monotonic(),
                               "ok": response.get("ok"),
                               "meaning": "scene dispatch returned; not a socket-delivery acknowledgement"}
        label = {"observe": "OBSERVE_REPLY", "get_state": "GET_STATE_REPLY",
                 "move_delta": "MOVE_REPLY"}.get(self.method, "REQUEST_REPLY")
        self.phase(label, sim_step, ok=response.get("ok"))

    def health(self):
        cached = self.snapshot
        return {"ok": True, "pid": os.getpid(), "alive": True,
                "main_phase": cached.get("phase"),
                "request_id": cached.get("request_id"),
                "sim_step": cached.get("sim_step"),
                "phase_monotonic_time": cached.get("monotonic_time"),
                "last_completed_request": cached.get("last_completed_request"),
                "wall_time_unix": time.time(), "monotonic_time": time.monotonic(),
                "scope": "process responding; cached metadata only; no scene-liveness claim"}

    def wrap(self, owner, method, label, step):
        original = getattr(owner, method)

        @wraps(original)
        def traced(*args, **kwargs):
            self.phase(label + "_ENTER", step())
            try:
                result = original(*args, **kwargs)
            except BaseException as error:
                self.phase(label + "_ERROR", step(), error_type=type(error).__name__)
                raise
            self.phase(label + "_EXIT", step())
            return result

        setattr(owner, method, traced)

    def close(self):
        self.stream.close()
